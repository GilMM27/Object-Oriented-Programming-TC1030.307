#include "mygame.h"

int main() {
    MyGame game;
    game.start();
    return 0;
}
